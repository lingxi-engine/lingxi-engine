# -*- coding: utf-8 -*-
import io, sys, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
html = open('design-preview.html', encoding='utf-8').read()
print('总长度:', len(html))
# 检查旧方案是否残留
for kw in ['感应核心', 'gTile', 'eTile', 'fTileShadow', 'v10A2', 'v10C', '犀角', 'gHorn', 'horn']:
    print('残留检查', kw, '->', html.count(kw))
# 新方案检查
for kw in ['gOrb', 'gNucleus', 'gRing', 'gShadow', 'gHalo', '立体水晶球', 'v12']:
    print('新方案', kw, '->', html.count(kw))
# SVG 标签配对
print('svg 开:', html.count('<svg'), ' svg 闭:', html.count('</svg>'))
# 顶栏 SVG 区域
i = html.find('<svg class="logo-mark"')
j = html.find('</svg>', i)
print('顶栏 SVG 长度:', j-i)
# 检查 defs/filter 是否闭合
print('defs 开:', html.count('<defs>'), 'defs 闭:', html.count('</defs>'))
