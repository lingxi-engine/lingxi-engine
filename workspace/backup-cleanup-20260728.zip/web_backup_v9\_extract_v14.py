# -*- coding: utf-8 -*-
"""提取 design-preview.html 中的 v14 logo SVG + CSS 动效"""
import io, sys, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

html = open(r'C:\Users\Administrator\lingxi-engine\web\design-preview.html', encoding='utf-8').read()
print('preview len:', len(html))

# 1. 提取 logo-mark SVG
m = re.search(r'<svg[^>]*class="logo-mark"[^>]*>.*?</svg>', html, re.S)
if not m:
    m = re.search(r'class="logo-mark"[^>]*>.*?</svg>', html, re.S)
svg = m.group(0) if m else 'NOT FOUND'
print('SVG found:', svg != 'NOT FOUND', 'len', len(svg))
open(r'C:\Users\Administrator\lingxi-engine\web\_extract_svg.txt', 'w', encoding='utf-8').write(svg)

# 2. 提取 logo 相关 CSS（.topnav .logo 到 next 非logo规则）
m2 = re.search(r'\.topnav \.logo\{.*?\n\}', html, re.S)
print('logo css start:', bool(m2))

# 提取所有含 logo-mark / lx- / logo 的 css 规则块
css_blocks = []
for mm in re.finditer(r'([^{}@]+)\{([^{}]*)\}', html):
    sel = mm.group(1).strip()
    if ('logo-mark' in sel or 'logo' in sel.lower() or 'lx-' in sel or 'lShine' in sel or 'sat-' in sel or 'orbit-flow' in sel or 'ripple' in sel or 'halo' in sel or 'nucleus' in sel):
        css_blocks.append((sel, mm.group(2).strip()[:200]))

with open(r'C:\Users\Administrator\lingxi-engine\web\_extract_css.txt', 'w', encoding='utf-8') as f:
    for sel, body in css_blocks:
        f.write(f'=== {sel} ===\n{body}\n\n')
print('css blocks:', len(css_blocks))

# 3. 提取 keyframes
kfs = re.findall(r'@keyframes\s+([\w-]+)\s*\{.*?\n\}', html, re.S)
print('keyframes:', kfs)
