# -*- coding: utf-8 -*-
import io, re
s = io.open('design-preview.html', encoding='utf-8').read()
out = []
# 死代码应归零
for pat in ['l-halo','l-nucleus','l-core','l-vein','l-sat','lHalo','lNucleus','lCore','lVein']:
    out.append('dead %s: %d' % (pat, s.count(pat)))
# 保留项
for pat in ['l-shine','lShine','lx-halo-breathe','lx-nucleus-pulse','lx-glow-pulse','lx-ripple','lx-orbit-twinkle','animateMotion']:
    out.append('keep %s: %d' % (pat, s.count(pat)))
# 极简关闭列表
out.append('minimal close l-shine: %d' % s.count('body.theme-minimal .logo-mark .l-shine'))
# SVG class 完整性
m = re.search(r'<svg class="logo-mark".*?</svg>', s, re.S)
svg = m.group(0)
for c in ['halo','ripple r1','ripple r2','nucleus-glow','nucleus-dot','l-shine','orbit-dot d1','orbit-dot d2']:
    out.append('svg class "%s": %d' % (c, svg.count('class="'+c)))
io.open('_v13_final.txt','w',encoding='utf-8').write('\n'.join(out))
print('final check done')
