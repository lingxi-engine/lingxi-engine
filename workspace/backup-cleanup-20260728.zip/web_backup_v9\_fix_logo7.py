# -*- coding: utf-8 -*-
import io, re, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

p = 'design-preview.html'
html = open(p, encoding='utf-8').read()
orig_len = len(html)

# ── 1. 导航栏高度 58 → 64（root + retro 两处）──
n1 = html.count('--nav-h:58px')
html = html.replace('--nav-h:58px', '--nav-h:64px')
print('nav-h 替换:', n1, '处')

# ── 2. 图标 40 → 46px ──
html = html.replace('.logo-mark{width:40px;height:40px;', '.logo-mark{width:46px;height:46px;')

# ── 3. 主字 20 → 24px ──
old_b = '.logo-txt b{font-size:20px;font-weight:900;letter-spacing:.6px;background:linear-gradient(180deg,#fff 0%,color-mix(in srgb,var(--accent) 55%,#fff) 22%,var(--accent) 48%,color-mix(in srgb,var(--accent2) 85%,#000) 100%);-webkit-background-clip:text;background-clip:text;color:transparent;text-shadow:0 1px 0 rgba(255,255,255,.5),0 2px 0 color-mix(in srgb,var(--accent2) 74%,#000),0 3px 0 color-mix(in srgb,var(--accent2) 60%,#000),0 4px 0 color-mix(in srgb,var(--accent2) 46%,#000),0 6px 10px rgba(0,0,0,.32)}'
new_b = '.logo-txt b{font-size:24px;font-weight:900;letter-spacing:.6px;background:linear-gradient(180deg,#fff 0%,color-mix(in srgb,var(--accent) 55%,#fff) 22%,var(--accent) 48%,color-mix(in srgb,var(--accent2) 85%,#000) 100%);-webkit-background-clip:text;background-clip:text;color:transparent;text-shadow:0 1px 0 rgba(255,255,255,.5),0 2px 0 color-mix(in srgb,var(--accent2) 74%,#000),0 3px 0 color-mix(in srgb,var(--accent2) 60%,#000),0 4px 0 color-mix(in srgb,var(--accent2) 46%,#000),0 6px 10px rgba(0,0,0,.32)}'
assert old_b in html, '未找到 .logo-txt b'
html = html.replace(old_b, new_b)
print('主字样式 OK')

# ── 4. 英文小字 10 → 11px ──
html = html.replace('.logo-txt i{font-style:normal;font-size:10px;letter-spacing:2.8px;',
                    '.logo-txt i{font-style:normal;font-size:11px;letter-spacing:2.8px;')

# ── 5. 替换整个 SVG：超大立体「灵」字 + 一点光（品牌汉字徽标）──
new_svg = '''        <svg class="logo-mark" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <defs>
      <!-- 字面渐变：左上受光 → 右下暗（立体金属） -->
      <linearGradient id="gT" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="#ffffff"/>
        <stop offset=".35" stop-color="color-mix(in srgb,var(--accent) 45%,#fff)"/>
        <stop offset=".7" stop-color="var(--accent)"/>
        <stop offset="1" stop-color="color-mix(in srgb,var(--accent2) 72%,#000)"/>
      </linearGradient>
      <!-- 厚度面渐变（更暗） -->
      <linearGradient id="gSide" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="color-mix(in srgb,var(--accent2) 55%,#000)"/>
        <stop offset="1" stop-color="color-mix(in srgb,var(--accent2) 30%,#000)"/>
      </linearGradient>
      <!-- 一点光晕（灵犀一点） -->
      <radialGradient id="gDot" cx=".5" cy=".5" r=".5">
        <stop offset="0" stop-color="#fff"/>
        <stop offset=".5" stop-color="#fff" stop-opacity=".8"/>
        <stop offset="1" stop-color="var(--accent)" stop-opacity="0"/>
      </radialGradient>
    </defs>
    <!-- 地面投影 -->
    <ellipse cx="32" cy="58" rx="17" ry="3.2" fill="#000" opacity=".30"/>
    <!-- 厚度层（3D 挤出，整体下移 5px） -->
    <text x="32" y="53.5" text-anchor="middle" font-size="43" font-weight="900" font-family="inherit" fill="url(#gSide)">灵</text>
    <!-- 字面主体（金属渐变受光） -->
    <text x="32" y="48.5" text-anchor="middle" font-size="43" font-weight="900" font-family="inherit" fill="url(#gT)">灵</text>
    <!-- 字面左上高光描边（玻璃反光） -->
    <text x="32" y="48.5" text-anchor="middle" font-size="43" font-weight="900" font-family="inherit" fill="none" stroke="#fff" stroke-opacity=".28" stroke-width=".9">灵</text>
    <!-- 灵犀一点：字右下方发光点 -->
    <circle cx="49.5" cy="50.5" r="6.5" fill="url(#gDot)"/>
    <circle cx="49.5" cy="50.5" r="2.6" fill="#fff"/>
  </svg>'''

pattern = re.compile(r'<svg class="logo-mark".*?</svg>', re.S)
m = pattern.search(html)
assert m, '未找到旧 SVG'
html = html[:m.start()] + new_svg + html[m.end():]
print('SVG 替换 OK')

# ── 6. 版本注释 ──
html = html.replace('v8（3D Logo + 个人信息 + 主题风格）', 'v9（超大立体「灵」字徽标 + 个人信息 + 主题风格）')
html = html.replace('/* 品牌 Logo（3D 立体「灵」字印章 + 金属浮雕字标，v8 重设计） */',
                    '/* 品牌 Logo（超大立体「灵」字徽标 + 金属渐变 + 灵犀一点，v9 重设计） */')

open(p, 'w', encoding='utf-8').write(html)
print('写入完成, 长度:', orig_len, '->', len(html))
