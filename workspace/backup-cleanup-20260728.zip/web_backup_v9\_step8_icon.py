# -*- coding: utf-8 -*-
"""步骤8：生成静态水晶球 icon.svg（favicon 用，硬编码颜色）"""
import io, sys, os, shutil
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# 基于 preview SVG 转静态版：去掉所有动效 class、CSS 变量替换为硬编码值
STATIC_SVG = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
  <defs>
    <radialGradient id="gOrb" cx="0.30" cy="0.26" r="0.95">
      <stop offset="0" stop-color="#ffffff"/>
      <stop offset=".16" stop-color="#9cc9ff"/>
      <stop offset=".52" stop-color="#58a6ff"/>
      <stop offset=".84" stop-color="#1f3a5f"/>
      <stop offset="1" stop-color="#0a1526"/>
    </radialGradient>
    <radialGradient id="gNucleus" cx=".5" cy=".5" r=".5">
      <stop offset="0" stop-color="#ffffff"/>
      <stop offset=".38" stop-color="#ffffff" stop-opacity=".9"/>
      <stop offset=".72" stop-color="#58a6ff" stop-opacity=".5"/>
      <stop offset="1" stop-color="#58a6ff" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="gRing" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0" stop-color="#3d5a80"/>
      <stop offset=".5" stop-color="#ffffff"/>
      <stop offset="1" stop-color="#152238"/>
    </linearGradient>
    <radialGradient id="gShadow" cx=".5" cy=".5" r=".5">
      <stop offset="0" stop-color="#000" stop-opacity=".5"/>
      <stop offset="1" stop-color="#000" stop-opacity="0"/>
    </radialGradient>
    <radialGradient id="gHalo" cx=".5" cy=".5" r=".5">
      <stop offset="0" stop-color="#58a6ff" stop-opacity=".32"/>
      <stop offset="1" stop-color="#58a6ff" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <circle cx="32" cy="30" r="30" fill="url(#gHalo)"/>
  <g transform="rotate(-10 32 30)">
    <path d="M4 30 A28 12 0 0 1 60 30" fill="none" stroke="#152238" stroke-width="2.2" opacity=".5"/>
  </g>
  <circle cx="32" cy="30" r="19.5" fill="url(#gOrb)"/>
  <circle cx="32" cy="30" r="10.5" fill="url(#gNucleus)"/>
  <circle cx="32" cy="30" r="3" fill="#ffffff" opacity=".92"/>
  <path d="M21.5 18.8 A15 15 0 0 1 41 16.6" fill="none" stroke="#ffffff" stroke-opacity=".88" stroke-width="2.4" stroke-linecap="round"/>
  <path d="M24 24 A11 11 0 0 1 33 20.6" fill="none" stroke="#ffffff" stroke-opacity=".32" stroke-width="3.2" stroke-linecap="round"/>
  <path d="M19.5 42.8 A15.5 15.5 0 0 0 44.5 42.8" fill="none" stroke="#ffffff" stroke-opacity=".22" stroke-width="1.8" stroke-linecap="round"/>
  <g transform="rotate(-10 32 30)">
    <path d="M4 30 A28 12 0 0 0 60 30" fill="none" stroke="url(#gRing)" stroke-width="2.6" stroke-linecap="round"/>
  </g>
  <ellipse cx="32" cy="56" rx="15.5" ry="3.4" fill="url(#gShadow)"/>
</svg>'''

base = r'C:\Users\Administrator\lingxi-engine'
for rel in ['icon.svg', os.path.join('web', 'icon.svg')]:
    p = os.path.join(base, rel)
    if os.path.exists(p):
        shutil.copy(p, p + '.bak-pre-logo')
        print('[bak]', rel)
    open(p, 'w', encoding='utf-8', newline='\n').write(STATIC_SVG)
    print('[write]', rel, len(STATIC_SVG), 'bytes')

# manifest.json 检查 icon 引用
mf = os.path.join(base, 'manifest.json')
if os.path.exists(mf):
    m = open(mf, encoding='utf-8').read()
    print('\nmanifest.json:', m[:300])
