# -*- coding: utf-8 -*-
"""检查 mobile.css 完整 + model-management 引用"""
import io, sys, re, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

base = r'C:\Users\Administrator\lingxi-engine'

# mobile.css 完整内容
mc = os.path.join(base, 'web', 'css', 'mobile.css')
mcss = open(mc, encoding='utf-8').read()
print('=== web/css/mobile.css ===')
print(mcss)
print()

# model-management.html 引用哪些 css
mm = os.path.join(base, 'web', 'model-management.html')
h = open(mm, encoding='utf-8').read()
print('=== model-management.html css/js links ===')
for m in re.finditer(r'<(link|script)[^>]*(href|src)="([^"]+)"', h):
    print(' ', m.group(0)[:150])

# 根目录 model-management.html 是否存在？
rmm = os.path.join(base, 'model-management.html')
print('\n根 model-management.html exists:', os.path.exists(rmm))
if os.path.exists(rmm):
    h2 = open(rmm, encoding='utf-8').read()
    print('  引用:')
    for m in re.finditer(r'<(link|script)[^>]*(href|src)="([^"]+)"', h2):
        print('   ', m.group(0)[:150])
