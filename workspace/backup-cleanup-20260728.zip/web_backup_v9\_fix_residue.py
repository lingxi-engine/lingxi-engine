# -*- coding: utf-8 -*-
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
html = open('design-preview.html', encoding='utf-8').read()

# 1. show-head 描述更新
html = html.replace(
    '顶栏已换「苹果风·感应核心」，备选两个可随时切换',
    '顶栏已换「苹果风·立体水晶球」，备选两个可随时切换'
)

# 2. CSS 注释更新
html = html.replace(
    '/* 品牌 Logo（灵犀角 · 一点通，v11 重设计） */',
    '/* 品牌 Logo（立体水晶球 · 一点通，v12 重设计） */'
)

# 3. showcase 注释更新
html = html.replace(
    '<!-- ═══ Logo 方案对比（v10：四个方向任选）═══ -->',
    '<!-- ═══ Logo 方案对比（v12：立体水晶球 + 备选）═══ -->'
)

open('design-preview.html', 'w', encoding='utf-8', newline='\n').write(html)
print('done')
