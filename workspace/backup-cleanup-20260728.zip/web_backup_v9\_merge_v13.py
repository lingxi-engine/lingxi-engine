# -*- coding: utf-8 -*-
"""v13 合并：清理我注入的 l- 死代码，保留 l-shine 扫光，并入极简关闭列表"""
import io, re

P = 'design-preview.html'
s = io.open(P, 'r', encoding='utf-8').read()

# ---- 1. 删除我注入的整块 l- 动画 CSS（含 l-shine 规则和 keyframes），稍后单独恢复 l-shine ----
start_marker = '/* v13 动效：水晶球注入生命（呼吸·脉动·公转·扫光） */'
end_marker = 'body.theme-minimal .logo-mark .l-sat{display:none}'
i = s.find(start_marker)
j = s.find(end_marker)
assert i != -1 and j != -1 and j > i, 'markers not found'
j += len(end_marker)
block = s[i:j]
s = s[:i] + s[j:]
print('removed l- block len:', len(block))

# ---- 2. 重新注入 l-shine 扫光（只保留它，放并行会话 lx- 区块之后） ----
shine_css = '''
/* 高光扫光（玻璃反光掠过 · 与 lx 体系共存） */
.logo-mark .l-shine{stroke-dasharray:34 150;animation:lShine 6s linear infinite}
@keyframes lShine{0%{stroke-dashoffset:0}50%{stroke-dashoffset:-184}100%{stroke-dashoffset:-184}}
'''
anchor = '@media (prefers-reduced-motion: reduce){'
assert anchor in s, 'lx media anchor not found'
s = s.replace(anchor, shine_css + '\n' + anchor, 1)

# ---- 3. 极简关闭列表加上 l-shine ----
s = s.replace(
    'body.theme-minimal .logo-mark .orbit-dot{animation:none}',
    'body.theme-minimal .logo-mark .orbit-dot,\nbody.theme-minimal .logo-mark .l-shine{animation:none}'
)
# 也加入 reduced-motion 列表
s = s.replace(
    '  .logo-mark .orbit-dot{animation:none}',
    '  .logo-mark .orbit-dot,\n  .logo-mark .l-shine{animation:none}'
)

io.open(P, 'w', encoding='utf-8', newline='').write(s)
print('merged OK')
