# -*- coding: utf-8 -*-
"""步骤6：model-management.html logo 用法详情"""
import io, sys, re, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

base = r'C:\Users\Administrator\lingxi-engine'
p = os.path.join(base, 'web', 'model-management.html')
h = open(p, encoding='utf-8', errors='replace').read()

# logo class 上下文
for m in re.finditer(r'class="logo"', h):
    i = m.start()
    print('=== class="logo" @', i, '===')
    print(h[max(0,i-300):i+300])
    print()

# css 引用方式（style 标签？）
styles = re.findall(r'<style[^>]*>', h)
print('style tags:', styles[:5])

# 找 <link 全部
links = re.findall(r'<link[^>]*>', h)
print('links:', links[:10])

# head 部分
head = h[:h.find('</head>')]
print('\n=== HEAD ===')
print(head[:2000])
