import re

p = 'web/design-preview.html'
s = open(p, encoding='utf-8').read()
orig = s

# ── 1. 替换 Logo SVG：线框松鼠 → 灵字晶体 ──
new_svg = '''  <svg class="logo-mark" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <defs>
      <linearGradient id="lgSq" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="var(--accent)"/>
        <stop offset="1" stop-color="var(--accent2)"/>
      </linearGradient>
      <filter id="lgF" x="-80%" y="-80%" width="260%" height="260%">
        <feGaussianBlur stdDeviation="1.2" result="b"/>
        <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
      </filter>
    </defs>
    <!-- 晶体菱形底（渐变 + 细描边） -->
    <rect x="7" y="7" width="34" height="34" rx="9" transform="rotate(45 24 24)" fill="url(#lgSq)"/>
    <rect x="7" y="7" width="34" height="34" rx="9" transform="rotate(45 24 24)" fill="none" stroke="#fff" stroke-opacity=".22" stroke-width="1.1"/>
    <!-- 灵字（点题） -->
    <text x="24" y="25.8" text-anchor="middle" font-size="17" font-weight="700" fill="#fff" font-family="inherit">灵</text>
    <!-- 一点通光点（灵犀一点通） -->
    <circle cx="34.5" cy="34.5" r="3.2" fill="#fff" filter="url(#lgF)"/>
    <circle cx="34.5" cy="34.5" r="1.6" fill="#fff"/>
  </svg>'''

s, n1 = re.subn(r'  <svg class="logo-mark".*?</svg>', new_svg, s, count=1, flags=re.S)

# ── 2. CSS 注释 ──
s = s.replace('/* 品牌 Logo（科技线框松鼠 + 发光，v4 重设计） */',
              '/* 品牌 Logo（灵字晶体 + 渐变发光字标，v6 重设计） */')

# ── 3. 品牌文字：加大字重 + 渐变（带兼容回退）──
old_b = '.logo-txt b{font-size:15px;font-weight:700}'
new_b = ('.logo-txt b{font-size:16px;font-weight:800;color:var(--accent);letter-spacing:.5px}\n'
         '@supports((-webkit-background-clip:text) or (background-clip:text)){'
         '.logo-txt b{background:linear-gradient(90deg,var(--accent),var(--accent2));'
         '-webkit-background-clip:text;background-clip:text;color:transparent;-webkit-text-fill-color:transparent}}')
assert old_b in s, 'logo-txt b 样式未找到'
s = s.replace(old_b, new_b)

# ── 4. 说明条 & 标题 ──
s = s.replace('📐 设计稿 v5 — Logo 重设计（科技松鼠）+ 积分/钱包拆分 + 6 套主题',
              '📐 设计稿 v6 — Logo 重设计（灵字晶体字标）+ 积分/钱包拆分 + 6 套主题')
s = s.replace('灵犀引擎 · 新布局设计稿 v4（个人信息 + 主题风格）',
              '灵犀引擎 · 新布局设计稿 v6（个人信息 + 主题风格）')

open(p, 'w', encoding='utf-8').write(s)
print('svg replaced:', n1)
print('changed:', s != orig)
