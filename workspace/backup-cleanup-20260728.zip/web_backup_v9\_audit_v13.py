# -*- coding: utf-8 -*-
import io, re
s = io.open('design-preview.html', encoding='utf-8').read()
out = []
# 1. l-shine 相关 CSS
for pat in ['l-shine', 'lShine', 'lHalo', 'lNucleus', 'lCore', 'lVein', 'l-sat', 'l-halo', 'l-nucleus', 'l-core', 'l-vein']:
    idxs = [m.start() for m in re.finditer(re.escape(pat), s)]
    out.append('=== %s (%d 处) ===' % (pat, len(idxs)))
    for i in idxs[:3]:
        out.append(s[max(0,i-80):i+120].replace('\r','').replace('\n',' '))
# 2. lx 动画 keyframes 是否存在
for k in ['lx-halo-breathe','lx-nucleus-pulse','lx-glow-pulse','lx-ripple','lx-orbit-twinkle']:
    out.append('keyframes %s: %d' % (k, s.count('@keyframes '+k)))
io.open('_v13_audit.txt','w',encoding='utf-8').write('\n'.join(out))
print('audit done')
