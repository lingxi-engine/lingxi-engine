# -*- coding: utf-8 -*-
import re, sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
html = open('design-preview.html', encoding='utf-8').read()
print('LEN:', len(html))
classes = re.findall(r'class="([^"]+)"', html)
logo_cls = [c for c in classes if re.search(r'logo|brand|orb|sphere|globe|orb', c, re.I)]
print('LOGO CLASSES:', logo_cls[:30])
svgs = re.findall(r'<svg', html)
print('SVG COUNT:', len(svgs))
# 找 svg 内容
for i, mm in enumerate(re.finditer(r'<svg.*?</svg>', html, re.S)):
    seg = mm.group(0)
    if len(seg) < 6000:
        print(f'--- SVG #{i} ({len(seg)} chars) ---')
        print(seg[:2500])
        print()
