import sys
s = open('web/design-preview.html', encoding='utf-8').read()
lines = s.splitlines()
out = []
for i in range(295, 370):
    if i < len(lines):
        out.append(f"{i+1}: {lines[i]}")
open('web/_dump_logo2.txt', 'w', encoding='utf-8').write("\n".join(out))
print("ok", len(out))
