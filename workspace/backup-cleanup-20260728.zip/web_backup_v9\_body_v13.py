# -*- coding: utf-8 -*-
import io, re
s = io.open('design-preview.html', encoding='utf-8').read()
m = re.search(r'<svg class="logo-mark".*?</svg>', s, re.S)
svg = m.group(0)
out = []
# 检查闭合标签平衡
out.append('svg opens: %d  closes: %d' % (svg.count('<svg'), svg.count('</svg>')))
out.append('circle open: %d close: %d' % (svg.count('<circle'), svg.count('</circle>')))
out.append('path open: %d close: %d' % (svg.count('<path'), svg.count('</path>')))
out.append('g open: %d close: %d' % (svg.count('<g'), svg.count('</g>')))
out.append('defs open: %d close: %d' % (svg.count('<defs'), svg.count('</defs>')))
# 打印 SVG 后半段（球体之后部分）
i = svg.find('球体本体')
out.append('--- 从球体本体开始 ---')
out.append(svg[i-50:])
io.open('_v13_svgbody.txt','w',encoding='utf-8').write('\n'.join(out))
print('svg body check done')
