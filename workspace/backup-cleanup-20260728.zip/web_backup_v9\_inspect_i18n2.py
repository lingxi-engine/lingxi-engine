# -*- coding: utf-8 -*-
import re, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

i18n = open(r'C:\Users\Administrator\lingxi-engine\web\js\i18n.js', encoding='utf-8').read()
out = []
out.append('i18n_len=%d' % len(i18n))
# app.name 定义
for kw in ['app.name', 'applyLanguage', 'data-i18n']:
    idxs = [m.start() for m in re.finditer(re.escape(kw), i18n)]
    out.append('%s count=%d idx=%s' % (kw, len(idxs), idxs[:5]))

# 找 app.name 定义上下文
m = re.search(r'app\.name[^\n]{0,120}', i18n)
if m:
    out.append('app.name def: ' + m.group(0))

# applyLanguage 实现
i = i18n.find('function applyLanguage')
if i < 0:
    i = i18n.find('applyLanguage')
out.append('--- applyLanguage @%d ---' % i)
out.append(i18n[i:i+900])

with open(r'C:\Users\Administrator\lingxi-engine\web\_i18n2.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(out))
print('DONE')
