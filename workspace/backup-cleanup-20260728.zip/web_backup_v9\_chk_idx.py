# -*- coding: utf-8 -*-
import io, sys, os, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

p = r'C:\Users\Administrator\lingxi-engine\web\index.html'
print('exists:', os.path.exists(p), 'size:', os.path.getsize(p))
h = open(p, encoding='utf-8', errors='replace').read()
print('len:', len(h))

idx = [m.start() for m in re.finditer(r'logo', h, re.I)]
print('logo hits:', len(idx))
for i in idx[:12]:
    print('@', i, repr(h[max(0,i-110):i+170]))
    print('---')
