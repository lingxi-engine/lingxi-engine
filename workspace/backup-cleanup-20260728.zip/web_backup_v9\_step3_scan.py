# -*- coding: utf-8 -*-
"""步骤3：检查其他页面的 logo 冲突 + mobile.css 适配"""
import io, sys, re, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

base = r'C:\Users\Administrator\lingxi-engine'

# 1. model-management.html 的 .logo
mm = os.path.join(base, 'web', 'model-management.html')
h = open(mm, encoding='utf-8').read()
print('=== model-management.html ===')
for m in re.finditer(r'class="[^"]*logo[^"]*"', h):
    print('  class hit:', m.group(0))
# 查找 css 里的 .logo 定义
for m in re.finditer(r'\.logo\s*\{[^}]*\}', h):
    print('  css .logo:', m.group(0)[:150])
for m in re.finditer(r'<a[^>]*logo[^>]*>', h):
    print('  anchor:', m.group(0)[:200])

# 2. admin.html
adm = os.path.join(base, 'web', 'admin.html')
h2 = open(adm, encoding='utf-8').read()
print('\n=== admin.html ===')
for m in re.finditer(r'class="[^"]*logo[^"]*"', h2):
    print('  class hit:', m.group(0))
for m in re.finditer(r'<a[^>]*logo[^>]*>', h2):
    print('  anchor:', m.group(0)[:200])

# 3. 根目录 admin.html
adm2 = os.path.join(base, 'admin.html')
h3 = open(adm2, encoding='utf-8').read()
print('\n=== 根 admin.html ===')
for m in re.finditer(r'class="[^"]*logo[^"]*"', h3):
    print('  class hit:', m.group(0))
for m in re.finditer(r'<a[^>]*logo[^>]*>', h3):
    print('  anchor:', m.group(0)[:200])

# 4. mobile.css 是否有 .logo
mc = os.path.join(base, 'web', 'css', 'mobile.css')
if os.path.exists(mc):
    mcss = open(mc, encoding='utf-8').read()
    print('\n=== web/css/mobile.css === len', len(mcss))
    for m in re.finditer(r'\.logo[^{]*\{[^}]*\}', mcss):
        print('  css .logo:', m.group(0)[:200])
else:
    print('\n!!! web/css/mobile.css NOT FOUND')

# 5. 根 css 目录
rc = os.path.join(base, 'css')
if os.path.isdir(rc):
    print('\n=== 根 css/ 目录 ===')
    for f in os.listdir(rc):
        print(' ', f)
