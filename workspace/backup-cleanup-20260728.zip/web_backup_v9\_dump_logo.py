# -*- coding: utf-8 -*-
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
html = open('design-preview.html', encoding='utf-8').read()
print('=== 34500 到结尾 ===')
print(html[34500:43286])
