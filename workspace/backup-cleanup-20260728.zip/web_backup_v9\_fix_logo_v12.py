# -*- coding: utf-8 -*-
"""v12: 立体水晶球 + 环绕轨道（苹果风立体版）替换脚本"""
import io, sys, shutil, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

SRC = 'design-preview.html'
BAK = 'design-preview.html.bak-v11-0802'
html = open(SRC, encoding='utf-8').read()
shutil.copyfile(SRC, BAK)

# ═══════ 1. 新顶栏 logo SVG：立体水晶球 + 环绕轨道 ═══════
NEW_LOGO_SVG = '''<svg class="logo-mark" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <defs>
      <!-- 球体立体光照：光源左上，白→主题色→深色暗边（真实球体） -->
      <radialGradient id="gOrb" cx="0.30" cy="0.26" r="0.95">
        <stop offset="0" stop-color="#ffffff"/>
        <stop offset=".16" stop-color="color-mix(in srgb,var(--accent) 42%,#fff)"/>
        <stop offset=".52" stop-color="var(--accent)"/>
        <stop offset=".84" stop-color="color-mix(in srgb,var(--accent2) 70%,#000)"/>
        <stop offset="1" stop-color="color-mix(in srgb,var(--accent2) 94%,#000)"/>
      </radialGradient>
      <!-- 内部灵犀光核（一点通） -->
      <radialGradient id="gNucleus" cx=".5" cy=".5" r=".5">
        <stop offset="0" stop-color="#ffffff"/>
        <stop offset=".38" stop-color="#ffffff" stop-opacity=".9"/>
        <stop offset=".72" stop-color="var(--accent)" stop-opacity=".5"/>
        <stop offset="1" stop-color="var(--accent)" stop-opacity="0"/>
      </radialGradient>
      <!-- 轨道金属渐变（苹果银） -->
      <linearGradient id="gRing" x1="0" y1="0" x2="1" y2="0">
        <stop offset="0" stop-color="color-mix(in srgb,var(--accent2) 28%,#fff)"/>
        <stop offset=".5" stop-color="#ffffff"/>
        <stop offset="1" stop-color="color-mix(in srgb,var(--accent2) 42%,#000)"/>
      </linearGradient>
      <!-- 接触投影 -->
      <radialGradient id="gShadow" cx=".5" cy=".5" r=".5">
        <stop offset="0" stop-color="#000" stop-opacity=".5"/>
        <stop offset="1" stop-color="#000" stop-opacity="0"/>
      </radialGradient>
      <!-- 外发光 -->
      <radialGradient id="gHalo" cx=".5" cy=".5" r=".5">
        <stop offset="0" stop-color="var(--accent)" stop-opacity=".32"/>
        <stop offset="1" stop-color="var(--accent)" stop-opacity="0"/>
      </radialGradient>
    </defs>
    <!-- 外发光 -->
    <circle cx="32" cy="30" r="30" fill="url(#gHalo)"/>
    <!-- 后环（球体后面 · 暗 · 立体分层关键） -->
    <g transform="rotate(-10 32 30)">
      <path d="M4 30 A28 12 0 0 1 60 30" fill="none" stroke="color-mix(in srgb,var(--accent2) 42%,#000)" stroke-width="2.2" opacity=".5"/>
    </g>
    <!-- 球体本体 -->
    <circle cx="32" cy="30" r="19.5" fill="url(#gOrb)"/>
    <!-- 内部灵犀光核 -->
    <circle cx="32" cy="30" r="10.5" fill="url(#gNucleus)"/>
    <circle cx="32" cy="30" r="3" fill="#ffffff" opacity=".92"/>
    <!-- 左上玻璃高光弧（苹果式反光） -->
    <path d="M21.5 18.8 A15 15 0 0 1 41 16.6" fill="none" stroke="#ffffff" stroke-opacity=".88" stroke-width="2.4" stroke-linecap="round"/>
    <path d="M24 24 A11 11 0 0 1 33 20.6" fill="none" stroke="#ffffff" stroke-opacity=".32" stroke-width="3.2" stroke-linecap="round"/>
    <!-- 底部环境光反射（地面反弹，体积感关键） -->
    <path d="M19.5 42.8 A15.5 15.5 0 0 0 44.5 42.8" fill="none" stroke="#ffffff" stroke-opacity=".22" stroke-width="1.8" stroke-linecap="round"/>
    <!-- 前环（球体前面 · 亮 · 金属） -->
    <g transform="rotate(-10 32 30)">
      <path d="M4 30 A28 12 0 0 0 60 30" fill="none" stroke="url(#gRing)" stroke-width="2.6" stroke-linecap="round"/>
      <circle cx="61" cy="29" r="1.7" fill="#ffffff" opacity=".95"/>
    </g>
    <!-- 接触投影 -->
    <ellipse cx="32" cy="56" rx="15.5" ry="3.4" fill="url(#gShadow)"/>
  </svg>'''

# 定位顶栏 SVG：在 <a class="logo" ...> 内第一个 <svg class="logo-mark" 到 </svg>
start = html.find('<svg class="logo-mark"')
assert start != -1, '顶栏 SVG 起始未找到'
end = html.find('</svg>', start) + len('</svg>')
old_svg = html[start:end]
html = html[:start] + NEW_LOGO_SVG + html[end:]
print('顶栏 SVG 替换完成, 旧长度', len(old_svg), '-> 新长度', len(NEW_LOGO_SVG))

# ═══════ 2. 更新说明条标题 ═══════
html = html.replace(
    '📐 设计稿 v11 — Logo 苹果风重做（放弃动物/汉字，iOS 图标式感应核心）+ 6 套主题',
    '📐 设计稿 v12 — Logo 立体水晶球（苹果风·真体积感）+ 6 套主题'
)

# ═══════ 3. 更新 showcase 第一张卡片：替换为立体水晶球方案 ═══════
# 定位第一个 show-card 的完整内容
card_start = html.find('<div class="show-card">')
assert card_start != -1, 'show-card 未找到'
# 找到第一个卡片结束：下一个 </div> 前是 show-tag 的 </span>，用 </span>\n    </div> 定位
card_end_marker = '顶栏当前方案</span>\n    </div>'
card_end = html.find(card_end_marker, card_start)
assert card_end != -1, '第一张卡片结束未找到'
card_end += len(card_end_marker)

NEW_CARD1 = '''<div class="show-card">
      <div class="show-preview">
        <svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <radialGradient id="sOrb" cx="0.30" cy="0.26" r="0.95">
              <stop offset="0" stop-color="#ffffff"/>
              <stop offset=".16" stop-color="color-mix(in srgb,var(--accent) 42%,#fff)"/>
              <stop offset=".52" stop-color="var(--accent)"/>
              <stop offset=".84" stop-color="color-mix(in srgb,var(--accent2) 70%,#000)"/>
              <stop offset="1" stop-color="color-mix(in srgb,var(--accent2) 94%,#000)"/>
            </radialGradient>
            <radialGradient id="sNucleus" cx=".5" cy=".5" r=".5">
              <stop offset="0" stop-color="#ffffff"/>
              <stop offset=".38" stop-color="#ffffff" stop-opacity=".9"/>
              <stop offset=".72" stop-color="var(--accent)" stop-opacity=".5"/>
              <stop offset="1" stop-color="var(--accent)" stop-opacity="0"/>
            </radialGradient>
            <linearGradient id="sRing" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0" stop-color="color-mix(in srgb,var(--accent2) 28%,#fff)"/>
              <stop offset=".5" stop-color="#ffffff"/>
              <stop offset="1" stop-color="color-mix(in srgb,var(--accent2) 42%,#000)"/>
            </linearGradient>
            <radialGradient id="sShadow" cx=".5" cy=".5" r=".5">
              <stop offset="0" stop-color="#000" stop-opacity=".5"/>
              <stop offset="1" stop-color="#000" stop-opacity="0"/>
            </radialGradient>
            <radialGradient id="sHalo" cx=".5" cy=".5" r=".5">
              <stop offset="0" stop-color="var(--accent)" stop-opacity=".32"/>
              <stop offset="1" stop-color="var(--accent)" stop-opacity="0"/>
            </radialGradient>
          </defs>
          <circle cx="32" cy="30" r="30" fill="url(#sHalo)"/>
          <g transform="rotate(-10 32 30)">
            <path d="M4 30 A28 12 0 0 1 60 30" fill="none" stroke="color-mix(in srgb,var(--accent2) 42%,#000)" stroke-width="2.2" opacity=".5"/>
          </g>
          <circle cx="32" cy="30" r="19.5" fill="url(#sOrb)"/>
          <circle cx="32" cy="30" r="10.5" fill="url(#sNucleus)"/>
          <circle cx="32" cy="30" r="3" fill="#ffffff" opacity=".92"/>
          <path d="M21.5 18.8 A15 15 0 0 1 41 16.6" fill="none" stroke="#ffffff" stroke-opacity=".88" stroke-width="2.4" stroke-linecap="round"/>
          <path d="M24 24 A11 11 0 0 1 33 20.6" fill="none" stroke="#ffffff" stroke-opacity=".32" stroke-width="3.2" stroke-linecap="round"/>
          <path d="M19.5 42.8 A15.5 15.5 0 0 0 44.5 42.8" fill="none" stroke="#ffffff" stroke-opacity=".22" stroke-width="1.8" stroke-linecap="round"/>
          <g transform="rotate(-10 32 30)">
            <path d="M4 30 A28 12 0 0 0 60 30" fill="none" stroke="url(#sRing)" stroke-width="2.6" stroke-linecap="round"/>
            <circle cx="61" cy="29" r="1.7" fill="#ffffff" opacity=".95"/>
          </g>
          <ellipse cx="32" cy="56" rx="15.5" ry="3.4" fill="url(#sShadow)"/>
        </svg>
      </div>
      <div class="show-name">苹果风 · 立体水晶球</div>
      <div class="show-desc">真实球体光照（左上光源→底部环境反光）+ 玻璃高光 + 内部「一点通」光核 + 前后分层金属环绕轨道 + 接触投影。体积感来自光影分层，不是贴纸。</div>
      <span class="show-tag">顶栏当前方案</span>
    </div>'''

html = html[:card_start] + NEW_CARD1 + html[card_end:]
print('showcase 第一张卡片替换完成')

open(SRC, 'w', encoding='utf-8', newline='\n').write(html)
print('写入完成, 新长度', len(html))
