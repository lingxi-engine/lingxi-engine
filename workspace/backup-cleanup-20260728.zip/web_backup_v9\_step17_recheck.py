# -*- coding: utf-8 -*-
"""步骤17：复查 web/css/style.css 当前状态"""
import io, sys, re, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

base = r'C:\Users\Administrator\lingxi-engine'
p = os.path.join(base, 'web', 'css', 'style.css')
css = open(p, encoding='utf-8').read()
print('web css len:', len(css), 'mtime:', os.path.getmtime(p))

from collections import Counter
kf = re.findall(r'@keyframes\s+([\w-]+)', css)
print('keyframes:', Counter(kf))
print('dups:', [k for k, c in Counter(kf).items() if c > 1] or 'none')
print('braces:', css.count('{') - css.count('}'))

# 检查 nav-h
print('nav-h:', [l.strip() for l in css.splitlines() if '--nav-h' in l])
print('accent2 count:', css.count('--accent2'))
print('logo-mark count:', css.count('logo-mark'))
print('first .topnav .logo @', css.find('.topnav .logo'))
