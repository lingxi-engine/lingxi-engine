# -*- coding: utf-8 -*-
import io, re, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

p = 'design-preview.html'
html = open(p, encoding='utf-8').read()
orig_len = len(html)

# 1. 导航栏高度 44 -> 56（root + retro 两处）
n1 = html.count('--nav-h:44px')
html = html.replace('--nav-h:44px', '--nav-h:56px')
print('nav-h 替换:', n1, '处')

# 2. logo 尺寸：图标 28->42，gap 加大
html = html.replace(
  '.logo{display:flex;align-items:center;gap:7px;font-weight:700;font-size:15px;',
  '.logo{display:flex;align-items:center;gap:10px;font-weight:700;font-size:15px;')
html = html.replace(
  '.logo-mark{width:28px;height:28px;',
  '.logo-mark{width:42px;height:42px;')

# 3. 主字 16->22px，简化金属阴影
old_b = '.logo-txt b{font-size:16px;font-weight:800;letter-spacing:.4px;background:linear-gradient(180deg,#fff 0%,color-mix(in srgb,var(--accent) 52%,#fff) 24%,var(--accent) 50%,color-mix(in srgb,var(--accent2) 80%,#000) 100%);-webkit-background-clip:text;background-clip:text;color:transparent;text-shadow:0 1px 0 rgba(255,255,255,.45),0 2px 0 color-mix(in srgb,var(--accent2) 72%,#000),0 3px 0 color-mix(in srgb,var(--accent2) 58%,#000),0 4px 0 color-mix(in srgb,var(--accent2) 44%,#000),0 5px 0 color-mix(in srgb,var(--accent2) 30%,#000),0 7px 12px rgba(0,0,0,.30)}'
new_b = '.logo-txt b{font-size:22px;font-weight:800;letter-spacing:.6px;background:linear-gradient(180deg,#fff 0%,color-mix(in srgb,var(--accent) 55%,#fff) 30%,var(--accent) 55%,color-mix(in srgb,var(--accent2) 75%,#000) 100%);-webkit-background-clip:text;background-clip:text;color:transparent;text-shadow:0 1px 0 rgba(255,255,255,.4),0 2px 3px rgba(0,0,0,.28)}'
assert old_b in html, '未找到旧 .logo-txt b'
html = html.replace(old_b, new_b)
print('主字样式 OK')

# 4. 英文小字 8->9px
html = html.replace(
  '.logo-txt i{font-style:normal;font-size:8px;letter-spacing:2.4px;',
  '.logo-txt i{font-style:normal;font-size:9px;letter-spacing:2.6px;')

# 5. 替换整个 SVG
new_svg = '''        <svg class="logo-mark" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <defs>
      <!-- 顶面渐变：左上受光 -> 右下暗 -->
      <linearGradient id="gT" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="#ffffff"/>
        <stop offset=".45" stop-color="var(--accent)"/>
        <stop offset="1" stop-color="var(--accent2)"/>
      </linearGradient>
      <!-- 左侧面（中调） -->
      <linearGradient id="gL" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="color-mix(in srgb,var(--accent) 82%,#000)"/>
        <stop offset="1" stop-color="color-mix(in srgb,var(--accent2) 60%,#000)"/>
      </linearGradient>
      <!-- 右侧面（暗） -->
      <linearGradient id="gR" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="color-mix(in srgb,var(--accent2) 55%,#000)"/>
        <stop offset="1" stop-color="color-mix(in srgb,var(--accent2) 38%,#000)"/>
      </linearGradient>
      <!-- 核心光晕（灵犀一点） -->
      <radialGradient id="gCore" cx=".5" cy=".5" r=".5">
        <stop offset="0" stop-color="#fff"/>
        <stop offset=".55" stop-color="#fff" stop-opacity=".85"/>
        <stop offset="1" stop-color="var(--accent)" stop-opacity="0"/>
      </radialGradient>
    </defs>
    <!-- 落地投影（悬浮立体） -->
    <ellipse cx="32" cy="57.5" rx="17" ry="3.4" fill="#000" opacity=".30"/>
    <!-- 右侧面（暗） -->
    <path d="M56 19 L32 32 L32 55.5 L56 42.5 Z" fill="url(#gR)"/>
    <!-- 左侧面（中） -->
    <path d="M8 19 L32 32 L32 55.5 L8 42.5 Z" fill="url(#gL)"/>
    <!-- 顶面（亮，晶体台面） -->
    <path d="M32 5.5 L56 19 L32 32 L8 19 Z" fill="url(#gT)" stroke="rgba(255,255,255,.5)" stroke-width="1.1"/>
    <!-- 顶面高光边 -->
    <path d="M13.5 19.5 L32 9.8 L49 19.5" stroke="#fff" stroke-opacity=".75" stroke-width="1.7" fill="none" stroke-linecap="round"/>
    <!-- 棱线高光（立体感） -->
    <path d="M32 32 L32 55.5" stroke="rgba(255,255,255,.28)" stroke-width="1.2"/>
    <!-- 中央发光核心（灵犀一点） -->
    <circle cx="32" cy="19" r="8.5" fill="url(#gCore)"/>
    <circle cx="32" cy="19" r="3.6" fill="#fff"/>
    <circle cx="30.6" cy="17.6" r="1.4" fill="#fff"/>
  </svg>'''

pattern = re.compile(r'<svg class="logo-mark".*?</svg>', re.S)
m = pattern.search(html)
assert m, '未找到旧 SVG'
html = html[:m.start()] + new_svg + html[m.end():]
print('SVG 替换 OK')

# 6. 版本注释
html = html.replace('v8（3D Logo + 个人信息 + 主题风格）', 'v9（大尺寸 3D 晶体 Logo + 个人信息 + 主题风格）')
html = html.replace('/* 品牌 Logo（3D 立体「灵」字印章 + 金属浮雕字标，v8 重设计） */',
                    '/* 品牌 Logo（等轴测 3D 晶体 + 发光核心「灵犀一点」，v9 大尺寸重设计） */')

open(p, 'w', encoding='utf-8').write(html)
print('写入完成, 长度:', orig_len, '->', len(html))
