# -*- coding: utf-8 -*-
"""步骤2：嵌入 v14 水晶球 SVG 到正式 index.html"""
import io, sys, re, shutil
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

IDX = r'C:\Users\Administrator\lingxi-engine\web\index.html'
SVG_FILE = r'C:\Users\Administrator\lingxi-engine\web\_extract_svg.txt'

h = open(IDX, encoding='utf-8').read()
svg = open(SVG_FILE, encoding='utf-8').read().strip()
shutil.copy(IDX, IDX + '.bak-pre-logo')
print('[1] backup ok')

# 正式版 logo 结构：SVG + 主字 + 英文
NEW_LOGO = (
    '<a class="logo" href="/">\n'
    '  ' + svg + '\n'
    '  <span class="logo-txt"><b data-i18n="app.name">灵犀引擎</b><i>LINGXI ENGINE</i></span>\n'
    '</a>'
)

# 精确定位旧 logo
pat = re.compile(r'<a class="logo" href="/">.*?</a>', re.S)
m = pat.search(h)
if m:
    print('[2] old logo found:', repr(m.group(0)[:80]))
    h = h[:m.start()] + NEW_LOGO + h[m.end():]
    print('[2] replaced')
else:
    print('[2] !!! OLD LOGO NOT FOUND')

open(IDX, 'w', encoding='utf-8', newline='\n').write(h)
print('[3] index.html written, len', len(h))

# 验证
v = open(IDX, encoding='utf-8').read()
print('--- verify ---')
print('logo-mark count:', v.count('logo-mark'))
print('data-i18n app.name count:', v.count('data-i18n="app.name"'))
print('sat-front count:', v.count('sat-front'))
print('LINGXI count:', v.count('LINGXI'))
