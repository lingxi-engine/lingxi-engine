# -*- coding: utf-8 -*-
"""步骤10：检查 style.css 重复区域"""
import io, sys, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

p = r'C:\Users\Administrator\lingxi-engine\web\css\style.css'
css = open(p, encoding='utf-8').read()

# 找 logo 相关区域（第一个 .topnav .logo 到下一个非 logo 区块）
i = css.find('.topnav .logo')
print('first .topnav .logo @', i)
print(css[i-200:i+200])
print('\n...\n')

# 统计所有 keyframes 位置
for m in re.finditer(r'@keyframes\s+([\w-]+)', css):
    print('@', m.start(), m.group(1))
