# -*- coding: utf-8 -*-
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
s = open('design-preview.html', encoding='utf-8').read()
i = s.find('logo-mark')
j = s.find('<svg', i)
k = s.find('</svg>', j)
out = s[j:k+6]
print('SVG len:', len(out))
print('gHorn:', 'gHorn' in out, '| gLine:', 'gLine' in out, '| gTip:', 'gTip' in out)
print('horn path:', 'M18 53' in out)
print('tip circle:', '<circle cx="32" cy="11"' in out)
open('_verify2.txt', 'w', encoding='utf-8').write(out)
