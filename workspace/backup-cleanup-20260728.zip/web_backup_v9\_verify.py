# -*- coding: utf-8 -*-
import io, sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
s = io.open(r'C:\Users\Administrator\lingxi-engine\web\design-preview.html', encoding='utf-8').read()
print('file size:', len(s))
print('大粉红 count:', s.count('大粉红'))
print('粉红 button:', '>粉红</button>' in s)
# 主题切换按钮区
i = s.find('data-theme="pink"')
print('--- pink button ---')
print(s[i-260:i+120])
print()
print('--- pink theme css header ---')
j = s.find('主题六')
print(s[j-10:j+60])
print()
print('--- wallet row ---')
k = s.find('积分钱包')
print(s[k-30:k+160])
