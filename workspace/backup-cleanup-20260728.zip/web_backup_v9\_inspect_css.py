# -*- coding: utf-8 -*-
import re, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

css = open(r'C:\Users\Administrator\lingxi-engine\web\css\style.css', encoding='utf-8').read()
out = []
out.append('css_len=%d' % len(css))
for kw in ['.logo', 'topnav', 'logo-mark', 'logo-txt', 'nav-h', 'switchTheme', 'theme']:
    out.append('%s=%d' % (kw, len(re.findall(re.escape(kw), css))))
i = css.find('.logo')
out.append('css_logo_idx=%d' % i)
if i >= 0:
    out.append('---logo css region---')
    out.append(css[max(0, i-300):i+1200])

with open(r'C:\Users\Administrator\lingxi-engine\web\_cssidx.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(out))
print('DONE')
