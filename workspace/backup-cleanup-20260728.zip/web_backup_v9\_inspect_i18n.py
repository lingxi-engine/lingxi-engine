# -*- coding: utf-8 -*-
import re, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# 1. app.js 中 i18n 相关
js = open(r'C:\Users\Administrator\lingxi-engine\web\js\app.js', encoding='utf-8').read()
out = []
for m in re.finditer(r'i18n', js):
    s = max(0, m.start()-150)
    e = min(len(js), m.start()+250)
    out.append('--- i18n @%d ---' % m.start())
    out.append(js[s:e])
    out.append('')

with open(r'C:\Users\Administrator\lingxi-engine\web\_i18n.txt', 'w', encoding='utf-8') as f:
    f.write('\n'.join(out))
print('DONE')
