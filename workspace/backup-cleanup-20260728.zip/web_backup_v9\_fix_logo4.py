import re, shutil, datetime

p = 'web/design-preview.html'
bak = f'web/design-preview.html.bak-ling{datetime.datetime.now().strftime("%H%M%S")}'
shutil.copy(p, bak)

s = open(p, encoding='utf-8').read()
orig = s

# ── 1. 替换 Logo SVG：线框松鼠 → 灵字晶体 ──
new_svg = '''  <svg class="logo-mark" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <defs>
      <linearGradient id="lgSq" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="var(--accent)"/>
        <stop offset="1" stop-color="var(--accent2)"/>
      </linearGradient>
      <filter id="lgF" x="-80%" y="-80%" width="260%" height="260%">
        <feGaussianBlur stdDeviation="1.2" result="b"/>
        <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
      </filter>
    </defs>
    <!-- 晶体菱形底（渐变 + 细描边） -->
    <rect x="7" y="7" width="34" height="34" rx="9" transform="rotate(45 24 24)" fill="url(#lgSq)"/>
    <rect x="7" y="7" width="34" height="34" rx="9" transform="rotate(45 24 24)" fill="none" stroke="#fff" stroke-opacity=".22" stroke-width="1.1"/>
    <!-- 灵字（点题） -->
    <text x="24" y="25.8" text-anchor="middle" font-size="17" font-weight="700" fill="#fff" font-family="inherit">灵</text>
    <!-- 一点通光点（灵犀一点通） -->
    <circle cx="34.5" cy="34.5" r="3.2" fill="#fff" filter="url(#lgF)"/>
    <circle cx="34.5" cy="34.5" r="1.6" fill="#fff"/>
  </svg>'''

s, n1 = re.subn(r'  <svg class="logo-mark".*?</svg>', new_svg, s, count=1, flags=re.S)

# ── 2. CSS 注释同步 ──
s = s.replace('/* 品牌 Logo（科技线框松鼠 + 发光，v4 重设计） */',
              '/* 品牌 Logo（灵字晶体 + 渐变发光字标，v6 重设计） */')

# ── 3. 说明条 & 标题 版本号 ──
s = s.replace('设计稿 v5 — Logo 重设计（科技松鼠）', '设计稿 v6 — Logo 重设计（灵字晶体字标）')
s = s.replace('设计稿 v4（个人信息 + 主题风格）', '设计稿 v6（个人信息 + 主题风格）')
s = s.replace('v2.1-design', 'v2.2-design')

open(p, 'w', encoding='utf-8').write(s)
print('bak:', bak)
print('svg replaced:', n1)
print('changed:', s != orig)
print('squirrel remnants:', s.count('松鼠'), s.count('squirrel'))
