s = open('web/design-preview.html', encoding='utf-8').read()
lines = s.splitlines()
out = []
for i, l in enumerate(lines, 1):
    if 305 <= i <= 330 or '品牌 Logo' in l or '设计稿 v' in l or 'ver-tag' in l:
        out.append(f"{i}: {l}")
open('web/_verify_logo4.txt', 'w', encoding='utf-8').write("\n".join(out))
# 快速健全性检查
checks = {
    '有灵字 text': '<text x="24" y="25.8"' in s,
    '有晶体菱形 rect': 'transform="rotate(45 24 24)"' in s,
    '有一光点 circle': 'cx="34.5" cy="34.5" r="3.2"' in s,
    '无松鼠': '松鼠' not in s,
    '渐变字标保留': 'background-clip:text' in s,
    'minimal回退保留': 'theme-minimal .logo-txt b{background:none' in s,
}
out2 = []
for k, v in checks.items():
    out2.append(f"{'✅' if v else '❌'} {k}")
open('web/_verify_logo4_checks.txt', 'w', encoding='utf-8').write("\n".join(out2))
print("ok")
