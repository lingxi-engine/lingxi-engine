# -*- coding: utf-8 -*-
import io, sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
s = io.open(r'C:\Users\Administrator\lingxi-engine\web\design-preview.html', encoding='utf-8').read()
for kw in ['大粉红', '粉红', '钱包', 'theme-pink', 'theme', '钱包余额', '功能暂未开放']:
    idx = 0
    print('==== %s ====' % kw)
    while True:
        i = s.find(kw, idx)
        if i < 0:
            break
        print(i, repr(s[max(0, i-70):i+90]))
        idx = i + 1
