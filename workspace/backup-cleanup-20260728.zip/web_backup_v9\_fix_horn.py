# -*- coding: utf-8 -*-
import re, shutil, datetime, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
p = 'design-preview.html'
s = open(p, encoding='utf-8').read()
ts = datetime.datetime.now().strftime('%m%d%H%M')
shutil.copy(p, p + '.bak-horn-' + ts)

new_svg = '''<svg class="logo-mark" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <defs>
      <!-- 犀角主体：左上受光 -> 主题色 -> 右下暗（立体） -->
      <linearGradient id="gHorn" x1="0.15" y1="0.05" x2="0.95" y2="0.95">
        <stop offset="0" stop-color="#ffffff"/>
        <stop offset=".30" stop-color="color-mix(in srgb,var(--accent) 50%,#fff)"/>
        <stop offset=".65" stop-color="var(--accent)"/>
        <stop offset="1" stop-color="color-mix(in srgb,var(--accent2) 80%,#000)"/>
      </linearGradient>
      <!-- 灵犀光脉（贯通首尾的白线，下暗上亮） -->
      <linearGradient id="gLine" x1="0" y1="1" x2="0" y2="0">
        <stop offset="0" stop-color="#fff" stop-opacity=".18"/>
        <stop offset="1" stop-color="#fff" stop-opacity=".95"/>
      </linearGradient>
      <!-- 角尖灵光（一点通） -->
      <radialGradient id="gTip" cx=".5" cy=".5" r=".5">
        <stop offset="0" stop-color="#fff"/>
        <stop offset=".5" stop-color="#fff" stop-opacity=".7"/>
        <stop offset="1" stop-color="var(--accent)" stop-opacity="0"/>
      </radialGradient>
    </defs>
    <!-- 地面投影（悬浮） -->
    <ellipse cx="31" cy="57" rx="15" ry="3.2" fill="#000" opacity=".30"/>
    <!-- 犀角主体：弯曲锥形 -->
    <path d="M18 53 C 14 39 19 23 31 11 C 43 23 47 39 42 53 C 38 55 22 55 18 53 Z" fill="url(#gHorn)"/>
    <!-- 角质纹理（两条细弧，模拟角质层） -->
    <path d="M22 50 C 20 40 24 28 32 17" fill="none" stroke="color-mix(in srgb,var(--accent2) 35%,#000)" stroke-width="1" opacity=".5"/>
    <path d="M26 51 C 25 42 28 30 33 19" fill="none" stroke="color-mix(in srgb,var(--accent2) 35%,#000)" stroke-width=".8" opacity=".4"/>
    <!-- 灵犀光脉：贯通首尾的白色光带 -->
    <path d="M20 51 C 24 41 28 27 32 14" fill="none" stroke="url(#gLine)" stroke-width="2.2" stroke-linecap="round"/>
    <!-- 左上高光弧（玻璃/玉质反光） -->
    <path d="M21 48 C 18 38 22 24 30 13" fill="none" stroke="#fff" stroke-width="1.6" stroke-linecap="round" opacity=".5"/>
    <!-- 角尖灵光：一点通 -->
    <circle cx="32" cy="11" r="7" fill="url(#gTip)"/>
    <circle cx="32" cy="11" r="2.6" fill="#fff"/>
  </svg>'''

pat = re.compile(r'<svg class="logo-mark".*?</svg>', re.S)
s2, n = pat.subn(new_svg, s, count=1)
print('replaced:', n)

old_note = re.search(r'/\* 品牌 Logo[^\n]*\*/', s2)
if old_note:
    s2 = s2.replace(old_note.group(0), '/* 品牌 Logo（灵犀角 · 一点通，v11 重设计） */')
    print('note updated')

open(p, 'w', encoding='utf-8').write(s2)
print('OK', len(s), '->', len(s2))
