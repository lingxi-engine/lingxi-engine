# -*- coding: utf-8 -*-
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
s = open('design-preview.html', encoding='utf-8').read()
i = s.find('logo-mark')
j = s.find('<svg', i)
k = s.find('</svg>', j)
print('logo-mark idx:', i)
print('svg start:', j, 'svg end:', k)
print(s[j:k+6])
