# -*- coding: utf-8 -*-
"""步骤14：查看 10200-11300 确认第二套边界"""
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

p = r'C:\Users\Administrator\lingxi-engine\web\css\style.css'
css = open(p, encoding='utf-8').read()
print(css[10150:11350])
print('\n=== next section after 11350 ===')
print(css[11350:11500])
