# -*- coding: utf-8 -*-
"""步骤1：同步 v14 水晶球 Logo CSS 到正式 style.css"""
import io, sys, re, shutil
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

CSS = r'C:\Users\Administrator\lingxi-engine\web\css\style.css'
css = open(CSS, encoding='utf-8').read()
orig = css

# 备份
shutil.copy(CSS, CSS + '.bak-pre-logo')
print('[1] backup ok')

# ── 1. :root 补变量 ──
if '--accent2' not in css.split('[data-theme="light"]')[0]:
    css = css.replace(
        "  --mono: 'SF Mono','Fira Code','Consolas',monospace;",
        "  --mono: 'SF Mono','Fira Code','Consolas',monospace;\n  --bg4: #2d333b;\n  --accent2: #1f6feb;\n  --radius-sm: 5px;\n  --btn-radius: 5px;"
    )
    print('[2] :root vars patched')
else:
    print('[2] :root vars already present')

# ── 2. 各 [data-theme] 补 --accent2 ──
theme_accent2 = {
    'light':  '#0550ae',
    'ocean':  '#0d9488',
    'warm':   '#b45309',
    'forest': '#15803d',
}
for tname, a2 in theme_accent2.items():
    m = re.search(r'(\[data-theme="' + tname + r'"\]\{)([^}]*)(\})', css)
    if m:
        block = m.group(2)
        if '--accent2' not in block:
            if '--purple:' in block:
                block2 = re.sub(r'(--purple:[^;]*;)', r'\1 --accent2:' + a2 + ';', block, count=1)
            else:
                block2 = block.rstrip() + ' --accent2:' + a2 + ';'
            css = css[:m.start()] + m.group(1) + block2 + m.group(3) + css[m.end():]
            print('[2]', tname, 'accent2 =', a2)
        else:
            print('[2]', tname, 'already ok')
    else:
        print('[2] !!! theme not found:', tname)

# ── 3. 替换 .topnav .logo 旧规则 ──
NEW_LOGO_CSS = '''
/* ═══ 品牌 Logo：立体水晶球（苹果风 · v14 公转卫星）═══ */
.topnav .logo{display:flex;align-items:center;gap:10px;font-weight:800;font-size:19px;color:var(--accent);text-decoration:none;white-space:nowrap;letter-spacing:.4px}
.topnav .logo-mark{width:46px;height:46px;flex-shrink:0;filter:drop-shadow(0 5px 6px rgba(0,0,0,.32)) drop-shadow(0 1px 1px rgba(0,0,0,.22)) drop-shadow(0 0 8px color-mix(in srgb,var(--accent) 45%,transparent));transition:filter .3s,transform .3s}
.topnav .logo:hover .logo-mark{filter:drop-shadow(0 6px 10px rgba(0,0,0,.4)) drop-shadow(0 0 16px var(--accent));transform:translateY(-2px) scale(1.04)}
@keyframes lx-halo-breathe{0%,100%{opacity:.32;transform:scale(1)}50%{opacity:.5;transform:scale(1.06)}}
.topnav .logo-mark .halo{transform-origin:32px 30px;animation:lx-halo-breathe 3.8s ease-in-out infinite}
@keyframes lx-nucleus-pulse{0%,100%{transform:scale(1);opacity:.92}50%{transform:scale(1.32);opacity:1}}
.topnav .logo-mark .nucleus-dot{transform-origin:32px 30px;animation:lx-nucleus-pulse 2.4s ease-in-out infinite}
@keyframes lx-glow-pulse{0%,100%{opacity:.9}50%{opacity:.65}}
.topnav .logo-mark .nucleus-glow{animation:lx-glow-pulse 2.4s ease-in-out infinite}
@keyframes lx-ripple{0%{transform:scale(.28);opacity:.55;stroke-opacity:.55}70%{transform:scale(1.85);opacity:0;stroke-opacity:0}100%{transform:scale(1.85);opacity:0;stroke-opacity:0}}
.topnav .logo-mark .ripple{transform-origin:32px 30px;animation:lx-ripple 3.2s cubic-bezier(.25,.6,.35,1) infinite}
.topnav .logo-mark .ripple.r2{animation-delay:1.6s}
.topnav .logo-mark .orbit-flow{stroke-dasharray:7 61;animation:lx-flow 2.4s linear infinite}
@keyframes lx-sat{from{offset-distance:0%}to{offset-distance:100%}}
.topnav .logo-mark .sat-back{offset-path:path('M4 30 A28 12 0 1 1 60 30');animation:lx-sat 4s linear infinite}
.topnav .logo-mark .sat-back.s2{animation-delay:2s}
.topnav .logo-mark .sat-front{offset-path:path('M60 30 A28 12 0 1 1 4 30');animation:lx-sat 4s linear infinite;animation-delay:2s}
.topnav .logo-mark .sat-front.f0{animation-delay:0s}
.topnav .logo-mark .orbit-flow.accent{stroke-dasharray:5 63;animation-duration:1.6s;stroke-opacity:.7}
@keyframes lx-flow{to{stroke-dashoffset:-68}}
.topnav .logo:hover .logo-mark .ripple{animation-duration:1.5s}
.topnav .logo:hover .logo-mark .orbit-flow{animation-duration:1.2s}
.topnav .logo:hover .logo-mark .orbit-flow.accent{animation-duration:.8s}
.topnav .logo:hover .logo-mark .sat-back{animation-duration:2s}
.topnav .logo:hover .logo-mark .sat-back.s2{animation-delay:1s}
.topnav .logo:hover .logo-mark .sat-front{animation-duration:2s;animation-delay:1s}
.topnav .logo:hover .logo-mark .sat-front.f0{animation-delay:0s}
.topnav .logo-mark .l-shine{stroke-dasharray:34 150;animation:lShine 6s linear infinite}
@keyframes lShine{0%{stroke-dashoffset:0}50%{stroke-dashoffset:-184}100%{stroke-dashoffset:-184}}
@media (prefers-reduced-motion: reduce){
  .topnav .logo-mark .halo,
  .topnav .logo-mark .ripple,
  .topnav .logo-mark .nucleus-glow,
  .topnav .logo-mark .nucleus-dot,
  .topnav .logo-mark .orbit-flow,
  .topnav .logo-mark .l-shine{animation:none}
  .topnav .logo-mark .sat-back,
  .topnav .logo-mark .sat-front{animation:none;opacity:0}
  .topnav .logo-mark .orbit-flow.accent{animation:none}
}
.topnav .logo-txt{display:flex;flex-direction:column;line-height:1.1}
.topnav .logo-txt b{font-size:24px;font-weight:900;letter-spacing:.6px;background:linear-gradient(180deg,#fff 0%,color-mix(in srgb,var(--accent) 55%,#fff) 22%,var(--accent) 48%,color-mix(in srgb,var(--accent2) 85%,#000) 100%);-webkit-background-clip:text;background-clip:text;color:transparent;text-shadow:0 1px 0 rgba(255,255,255,.5),0 2px 0 color-mix(in srgb,var(--accent2) 74%,#000),0 3px 0 color-mix(in srgb,var(--accent2) 60%,#000),0 4px 0 color-mix(in srgb,var(--accent2) 46%,#000),0 6px 10px rgba(0,0,0,.32)}
.topnav .logo-txt i{font-style:normal;font-size:11px;letter-spacing:2.8px;color:var(--text3);font-family:var(--mono);margin-top:1px}
@media(max-width:1180px){.topnav .logo-txt i{display:none}}
'''

pat = re.compile(r'\.topnav \.logo\{[^}]*\}\n\.topnav \.logo:hover\{[^}]*\}')
m = pat.search(css)
if m:
    css = css[:m.start()] + NEW_LOGO_CSS + css[m.end():]
    print('[3] old .topnav .logo rules replaced')
else:
    print('[3] !!! OLD LOGO RULES NOT FOUND — manual check needed')

# ── 4. 顶栏高度 44→52 ──
before = css.count('--nav-h: 44px')
css = css.replace('--nav-h: 44px', '--nav-h: 52px')
after = css.count('--nav-h: 44px')
print('[4] nav-h 44px:', before, '-> remaining:', after)

open(CSS, 'w', encoding='utf-8', newline='\n').write(css)
print('[5] style.css written, len', len(css), '(was', len(orig), ')')

# 验证
v = open(CSS, encoding='utf-8').read()
print('--- verify ---')
print('accent2 count:', v.count('--accent2'))
print('logo-mark count:', v.count('logo-mark'))
print('keyframes:', [k for k in ['lx-halo-breathe','lx-nucleus-pulse','lx-glow-pulse','lx-ripple','lx-sat','lx-flow','lShine'] if k in v])
