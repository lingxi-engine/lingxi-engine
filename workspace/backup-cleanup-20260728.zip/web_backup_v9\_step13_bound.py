# -*- coding: utf-8 -*-
"""步骤13：定位 logo 区域边界"""
import io, sys, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

p = r'C:\Users\Administrator\lingxi-engine\web\css\style.css'
css = open(p, encoding='utf-8').read()

# 所有 logo 相关标记位置
marks = []
for pat in ['品牌 Logo', 'v13：水晶球', 'prefers-reduced-motion', '.topnav .logo-txt', 'lx-halo-breathe']:
    for m in re.finditer(re.escape(pat), css):
        marks.append((m.start(), pat))
marks.sort()
for pos, pat in marks:
    print('@', pos, pat)

# 第一个 '品牌 Logo' 前的上下文（确认从哪开始删）
i_first = css.find('品牌 Logo：立体水晶球')
print('\nfirst header ctx:')
print(css[i_first-120:i_first+80])

# 第二个 prefers-reduced-motion 块的结束位置
rms = [m.start() for m in re.finditer(r'@media \(prefers-reduced-motion: reduce\)', css)]
print('\nreduced-motion blocks @', rms)
if len(rms) >= 2:
    seg = css[rms[1]:]
    # 找到该块结束（第一个 '}' 后跟非缩进）
    j = seg.find('\n}\n')
    end2 = rms[1] + j + 3
    print('second block ends @', end2)
    print('tail after:', repr(css[end2:end2+120]))
