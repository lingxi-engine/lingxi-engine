# -*- coding: utf-8 -*-
"""步骤15：清理重复，替换为一份干净的 v14 Logo CSS"""
import io, sys, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

p = r'C:\Users\Administrator\lingxi-engine\web\css\style.css'
css = open(p, encoding='utf-8').read()

# 干净版 v14 CSS（单行紧凑，与 preview 一致）
CLEAN = '''
/* ═══ 品牌 Logo：立体水晶球（苹果风 · v14 公转卫星）═══ */
.topnav .logo{display:flex;align-items:center;gap:10px;font-weight:800;font-size:19px;color:var(--accent);text-decoration:none;white-space:nowrap;letter-spacing:.4px}
.topnav .logo-mark{width:46px;height:46px;flex-shrink:0;filter:drop-shadow(0 5px 6px rgba(0,0,0,.32)) drop-shadow(0 1px 1px rgba(0,0,0,.22)) drop-shadow(0 0 8px color-mix(in srgb,var(--accent) 45%,transparent));transition:filter .3s,transform .3s}
.topnav .logo:hover .logo-mark{filter:drop-shadow(0 6px 10px rgba(0,0,0,.4)) drop-shadow(0 0 16px var(--accent));transform:translateY(-2px) scale(1.04)}
/* 外发光呼吸 */
@keyframes lx-halo-breathe{0%,100%{opacity:.32;transform:scale(1)}50%{opacity:.5;transform:scale(1.06)}}
.topnav .logo-mark .halo{transform-origin:32px 30px;animation:lx-halo-breathe 3.8s ease-in-out infinite}
/* 灵犀核心脉冲（一点通 · 心跳） */
@keyframes lx-nucleus-pulse{0%,100%{transform:scale(1);opacity:.92}50%{transform:scale(1.32);opacity:1}}
.topnav .logo-mark .nucleus-dot{transform-origin:32px 30px;animation:lx-nucleus-pulse 2.4s ease-in-out infinite}
/* 核心光晕同步呼吸 */
@keyframes lx-glow-pulse{0%,100%{opacity:.9}50%{opacity:.65}}
.topnav .logo-mark .nucleus-glow{animation:lx-glow-pulse 2.4s ease-in-out infinite}
/* 感应涟漪（雷达波向外扩散） */
@keyframes lx-ripple{0%{transform:scale(.28);opacity:.55;stroke-opacity:.55}70%{transform:scale(1.85);opacity:0;stroke-opacity:0}100%{transform:scale(1.85);opacity:0;stroke-opacity:0}}
.topnav .logo-mark .ripple{transform-origin:32px 30px;animation:lx-ripple 3.2s cubic-bezier(.25,.6,.35,1) infinite}
.topnav .logo-mark .ripple.r2{animation-delay:1.6s}
/* 轨道能量流光 */
.topnav .logo-mark .orbit-flow{stroke-dasharray:7 61;animation:lx-flow 2.4s linear infinite}
/* 卫星公转：对置双星 4s 一周 · 上半圈球后真遮挡 */
@keyframes lx-sat{from{offset-distance:0%}to{offset-distance:100%}}
.topnav .logo-mark .sat-back{offset-path:path('M4 30 A28 12 0 1 1 60 30');animation:lx-sat 4s linear infinite}
.topnav .logo-mark .sat-back.s2{animation-delay:2s}
.topnav .logo-mark .sat-front{offset-path:path('M60 30 A28 12 0 1 1 4 30');animation:lx-sat 4s linear infinite;animation-delay:2s}
.topnav .logo-mark .sat-front.f0{animation-delay:0s}
/* accent 能量流光（与白色主光交错） */
.topnav .logo-mark .orbit-flow.accent{stroke-dasharray:5 63;animation-duration:1.6s;stroke-opacity:.7}
@keyframes lx-flow{to{stroke-dashoffset:-68}}
/* hover 引擎发力：涟漪 + 能量流 + 卫星加速 */
.topnav .logo:hover .logo-mark .ripple{animation-duration:1.5s}
.topnav .logo:hover .logo-mark .orbit-flow{animation-duration:1.2s}
.topnav .logo:hover .logo-mark .orbit-flow.accent{animation-duration:.8s}
.topnav .logo:hover .logo-mark .sat-back{animation-duration:2s}
.topnav .logo:hover .logo-mark .sat-back.s2{animation-delay:1s}
.topnav .logo:hover .logo-mark .sat-front{animation-duration:2s;animation-delay:1s}
.topnav .logo:hover .logo-mark .sat-front.f0{animation-delay:0s}
/* 高光扫光 */
.topnav .logo-mark .l-shine{stroke-dasharray:34 150;animation:lShine 6s linear infinite}
@keyframes lShine{0%{stroke-dashoffset:0}50%{stroke-dashoffset:-184}100%{stroke-dashoffset:-184}}
/* 极简主题降级 */
body.theme-minimal .logo-mark .halo,
body.theme-minimal .logo-mark .ripple,
body.theme-minimal .logo-mark .nucleus-glow,
body.theme-minimal .logo-mark .orbit-flow,
body.theme-minimal .logo-mark .l-shine{animation:none}
body.theme-minimal .logo-mark .sat-back,
body.theme-minimal .logo-mark .sat-front{animation:none;opacity:0}
body.theme-minimal .logo-mark .orbit-flow.accent{animation:none}
body.theme-minimal .logo-mark .nucleus-dot{animation:none}
/* 系统偏好减少动效：全部关闭 */
@media (prefers-reduced-motion: reduce){
  .topnav .logo-mark .halo,
  .topnav .logo-mark .ripple,
  .topnav .logo-mark .nucleus-glow,
  .topnav .logo-mark .nucleus-dot,
  .topnav .logo-mark .orbit-flow,
  .topnav .logo-mark .l-shine{animation:none}
  .topnav .logo-mark .sat-back,
  .topnav .logo-mark .sat-front{animation:none;opacity:0}
  .topnav .logo-mark .orbit-flow.accent{animation:none}
}
/* 文字部分 */
.topnav .logo-txt{display:flex;flex-direction:column;line-height:1.1}
.topnav .logo-txt b{font-size:24px;font-weight:900;letter-spacing:.6px;background:linear-gradient(180deg,#fff 0%,color-mix(in srgb,var(--accent) 55%,#fff) 22%,var(--accent) 48%,color-mix(in srgb,var(--accent2) 85%,#000) 100%);-webkit-background-clip:text;background-clip:text;color:transparent;text-shadow:0 1px 0 rgba(255,255,255,.5),0 2px 0 color-mix(in srgb,var(--accent2) 74%,#000),0 3px 0 color-mix(in srgb,var(--accent2) 60%,#000),0 4px 0 color-mix(in srgb,var(--accent2) 46%,#000),0 6px 10px rgba(0,0,0,.32)}
.topnav .logo-txt i{font-style:normal;font-size:11px;letter-spacing:2.8px;color:var(--text3);font-family:var(--mono);margin-top:1px}
@media(max-width:1180px){.topnav .logo-txt i{display:none}}
'''

# 定位开始：第一个 '品牌 Logo：立体水晶球' 注释
start = css.find('/* ═══ 品牌 Logo：立体水晶球')
if start == -1:
    start = css.find('品牌 Logo：立体水晶球')
    if start == -1:
        print('!!! start marker not found')
        sys.exit(1)
    # 回退到注释开头
    while start > 0 and css[start-1] != '\n':
        start -= 1
print('start @', start)

# 定位结束：第二个/最后一个 @media(max-width:1180px){.topnav .logo-txt i{display:none}}
ends = [m.start() for m in re.finditer(r'@media\(max-width:1180px\)\{\.topnav \.logo-txt i\{display:none\}\}', css)]
print('1180px ends @', ends)
if not ends:
    print('!!! end marker not found')
    sys.exit(1)
end = ends[-1] + len('@media(max-width:1180px){.topnav .logo-txt i{display:none}}')
print('end @', end)

# 替换
new_css = css[:start] + CLEAN + css[end:]
print('new len:', len(new_css), '(was', len(css), ')')

# 写回
open(p, 'w', encoding='utf-8', newline='\n').write(new_css)

# 验证
v = open(p, encoding='utf-8').read()
from collections import Counter
kf = re.findall(r'@keyframes\s+([\w-]+)', v)
print('keyframes after cleanup:', Counter(kf))
print('duplicates:', [k for k, c in Counter(kf).items() if c > 1] or 'none')
print('braces:', v.count('{') - v.count('}'))
print('len:', len(v))
