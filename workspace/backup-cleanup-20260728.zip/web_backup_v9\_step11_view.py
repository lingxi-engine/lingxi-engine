# -*- coding: utf-8 -*-
"""步骤11：查看两套 logo CSS 完整内容"""
import io, sys, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

p = r'C:\Users\Administrator\lingxi-engine\web\css\style.css'
css = open(p, encoding='utf-8').read()

# 第一套：从第一个 '品牌 Logo' 注释到 lShine 之后
i1 = css.find('品牌 Logo：立体水晶球')
i2 = css.find('@keyframes lShine', 5000)
print('=== 第一套 @', i1, '到', i2, '===')
print(css[i1-20:i2+200])
print('\n\n=== 第二套 @ 7500 附近 ===')
i3 = css.find('品牌 Logo', 5000)
print('second header @', i3)
print(css[i3-200:i3+300])
