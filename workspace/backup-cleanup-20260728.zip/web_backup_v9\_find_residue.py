# -*- coding: utf-8 -*-
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
html = open('design-preview.html', encoding='utf-8').read()
# 找残留位置
for kw in ['感应核心', '犀角']:
    i = 0
    while True:
        j = html.find(kw, i)
        if j == -1:
            break
        print('---', kw, '@', j, '---')
        print(html[max(0,j-120):j+160].replace('\n',' '))
        i = j + 1
