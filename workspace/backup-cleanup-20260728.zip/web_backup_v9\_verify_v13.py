# -*- coding: utf-8 -*-
import re, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
html = open('design-preview.html', encoding='utf-8').read()
checks = [
    'class="halo"', 'class="ripple r1"', 'class="ripple r2"',
    'class="nucleus-dot"', 'class="nucleus-glow"',
    'class="orbit-dot d1"', 'class="orbit-dot d2"',
    'lx-halo-breathe', 'lx-nucleus-pulse', 'lx-ripple', 'lx-orbit-twinkle',
    'prefers-reduced-motion', 'theme-minimal .logo-mark .halo',
]
for c in checks:
    print(('OK ' if c in html else 'MISSING ') + c)
print('showcase cards:', len(re.findall(r'show-card', html)))
print('total svg:', len(re.findall(r'<svg', html)))
