# -*- coding: utf-8 -*-
"""v13: 给水晶球 Logo 注入动效 - 呼吸光晕 + 核心脉动 + 轨道卫星 + 高光扫光"""
import io, re

P = 'design-preview.html'
src = io.open(P, 'r', encoding='utf-8').read()

# ---------- 1. 提取顶栏 logo-mark SVG（第一个） ----------
m = re.search(r'<svg class="logo-mark".*?</svg>', src, re.S)
assert m, 'logo-mark svg not found'
old_svg = m.group(0)

# ---------- 2. 替换元素 ----------
# 外发光 -> 呼吸
old_svg = old_svg.replace(
    '<circle cx="32" cy="30" r="30" fill="url(#gHalo)"/>',
    '<circle class="l-halo" cx="32" cy="30" r="30" fill="url(#gHalo)"/>'
)
# 光核 -> 脉动
old_svg = old_svg.replace(
    '<circle cx="32" cy="30" r="10.5" fill="url(#gNucleus)"/>',
    '<circle class="l-nucleus" cx="32" cy="30" r="10.5" fill="url(#gNucleus)"/>'
)
old_svg = old_svg.replace(
    '<circle cx="32" cy="30" r="3" fill="#ffffff" opacity=".92"/>',
    '<circle class="l-core" cx="32" cy="30" r="3" fill="#ffffff" opacity=".92"/>'
)
# 第一道高光弧 -> 扫光（加 dasharray 动画）
old_svg = old_svg.replace(
    '<path d="M21.5 18.8 A15 15 0 0 1 41 16.6" fill="none" stroke="#ffffff" stroke-opacity=".88" stroke-width="2.4" stroke-linecap="round"/>',
    '<path class="l-shine" d="M21.5 18.8 A15 15 0 0 1 41 16.6" fill="none" stroke="#ffffff" stroke-opacity=".88" stroke-width="2.4" stroke-linecap="round"/>'
)
# 前环卫星 -> 沿椭圆轨道公转（animateMotion 贴合轨道）
old_svg = old_svg.replace(
    '<circle cx="61" cy="29" r="1.7" fill="#ffffff" opacity=".95"/>',
    '<circle class="l-sat" cx="0" cy="0" r="1.7" fill="#ffffff" opacity=".95">'
    '<animateMotion dur="7s" repeatCount="indefinite" '
    'path="M4 30 A28 12 0 1 1 60 30 A28 12 0 1 1 4 30"/>'
    '</circle>'
)
# 球体内部加一条"灵犀光脉"（一点通的"通"）
old_svg = old_svg.replace(
    '<circle class="l-core" cx="32" cy="30" r="3" fill="#ffffff" opacity=".92"/>',
    '<circle class="l-core" cx="32" cy="30" r="3" fill="#ffffff" opacity=".92"/>'
    '<path class="l-vein" d="M27 25 C 30.5 29, 34 30.5, 38 35" fill="none" stroke="#ffffff" stroke-opacity=".38" stroke-width="1.1" stroke-linecap="round"/>'
)

src = src[:m.start()] + old_svg + src[m.end():]

# ---------- 3. 注入动效 CSS（放在 .logo:hover 规则后） ----------
anim_css = '''
/* v13 动效：水晶球注入生命（呼吸·脉动·公转·扫光） */
.logo-mark .l-halo{animation:lHalo 3.6s ease-in-out infinite}
.logo-mark .l-nucleus{animation:lNucleus 3s ease-in-out infinite}
.logo-mark .l-core{animation:lCore 3s ease-in-out infinite}
.logo-mark .l-shine{stroke-dasharray:34 150;animation:lShine 6s linear infinite}
.logo-mark .l-vein{animation:lVein 4s ease-in-out infinite}
@keyframes lHalo{0%,100%{opacity:.32}50%{opacity:.62}}
@keyframes lNucleus{0%,100%{opacity:1}50%{opacity:.6}}
@keyframes lCore{0%,100%{opacity:.92;transform:scale(1)}50%{opacity:.5;transform:scale(.8)}}
@keyframes lShine{0%{stroke-dashoffset:0}50%{stroke-dashoffset:-184}100%{stroke-dashoffset:-184}}
@keyframes lVein{0%,100%{opacity:.38}50%{opacity:.12}}
body.theme-minimal .logo-mark *{animation:none !important}
body.theme-minimal .logo-mark .l-sat{display:none}
'''
anchor = '.logo:hover .logo-mark{filter:drop-shadow(0 6px 10px rgba(0,0,0,.4)) drop-shadow(0 0 16px var(--accent));transform:translateY(-2px) scale(1.04)}'
assert anchor in src, 'anchor css not found'
src = src.replace(anchor, anchor + '\n' + anim_css)

io.open(P, 'w', encoding='utf-8', newline='').write(src)
print('OK v13 anim injected')
