s = open('web/design-preview.html', encoding='utf-8').read()
lines = s.splitlines()
out = []
for i, l in enumerate(lines, 1):
    if 'logo-txt' in l or 'logo-mark' in l or '品牌 Logo' in l or '松鼠' in l or 'squirrel' in l or '灵字' in l:
        out.append(f"{i}: {l}")
open('web/_dump_logo3.txt', 'w', encoding='utf-8').write("\n".join(out))
print("ok", len(out))
