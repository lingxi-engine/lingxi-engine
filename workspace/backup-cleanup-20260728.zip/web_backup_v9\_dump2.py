# -*- coding: utf-8 -*-
import io, sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
s = io.open(r'C:\Users\Administrator\lingxi-engine\web\design-preview.html', encoding='utf-8').read()
i = s.find('.pd-row{')
print('pd-row style at', i)
print(s[i-500:i+700])
