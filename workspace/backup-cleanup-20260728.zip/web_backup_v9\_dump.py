# -*- coding: utf-8 -*-
import io, sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
s = io.open(r'C:\Users\Administrator\lingxi-engine\web\design-preview.html', encoding='utf-8').read()
out = []
out.append('--- 22100-22400 ---')
out.append(s[22100:22400])
out.append('')
out.append('--- profile-card 首次出现 ---')
i = s.find('profile-card')
out.append(s[max(0,i-100):i+1000])
io.open(r'C:\Users\Administrator\lingxi-engine\web\_dump.txt','w',encoding='utf-8').write('\n'.join(out))
print('done', i)
