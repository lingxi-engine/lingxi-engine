# -*- coding: utf-8 -*-
import re, sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
html = open('design-preview.html', encoding='utf-8').read()
# 完整 SVG #0
mm = list(re.finditer(r'<svg.*?</svg>', html, re.S))
seg = mm[0].group(0)
print('=== FULL SVG #0 ===')
print(seg)
print()
# logo 相关 CSS
print('=== CSS (logo-related) ===')
for m in re.finditer(r'[^{}]*\.(?:logo|logo-mark|logo-txt)[^{}]*\{[^}]*\}', html):
    print(m.group(0).strip())
    print('---')
