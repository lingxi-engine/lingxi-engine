# -*- coding: utf-8 -*-
import io, sys, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
html = open('design-preview.html', encoding='utf-8').read()
print('总长度:', len(html))
for kw in ['感应核心', '犀角', 'gTile', 'eTile', 'v10A2', 'v10C', 'gHorn']:
    print('残留', kw, '->', html.count(kw))
for kw in ['gOrb', 'gNucleus', 'gRing', 'gShadow', 'gHalo', '立体水晶球']:
    print('新方案', kw, '->', html.count(kw))
print('svg:', html.count('<svg'), '/', html.count('</svg>'))
print('defs:', html.count('<defs>'), '/', html.count('</defs>'))
print('linearGradient:', html.count('<linearGradient'), '/', html.count('</linearGradient>'))
print('radialGradient:', html.count('<radialGradient'), '/', html.count('</radialGradient>'))
print('title 检查:', 'v12' in html)
# 极简主题降级仍在
print('极简降级:', 'theme-minimal .logo-mark' in html)
