# -*- coding: utf-8 -*-
"""步骤4：确认文件归属 + 引用顺序"""
import io, sys, re, os, hashlib
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

base = r'C:\Users\Administrator\lingxi-engine'

def md5(p):
    return hashlib.md5(open(p,'rb').read()).hexdigest()[:10]

# 1. 根 css/style.css vs web/css/style.css 是否相同
pairs = [
    ('根 css/style.css', os.path.join(base,'css','style.css')),
    ('web/css/style.css', os.path.join(base,'web','css','style.css')),
    ('根 css/mobile.css', os.path.join(base,'css','mobile.css')),
    ('web/css/mobile.css', os.path.join(base,'web','css','mobile.css')),
    ('根 model-management.html', os.path.join(base,'model-management.html')),
    ('web/model-management.html', os.path.join(base,'web','model-management.html')),
]
for name, p in pairs:
    if os.path.exists(p):
        print(name, 'exists', os.path.getsize(p), 'md5', md5(p))
    else:
        print(name, 'MISSING')

# 2. web/index.html 引用的 css/js 顺序
h = open(os.path.join(base,'web','index.html'), encoding='utf-8').read()
print('\n=== web/index.html head 引用 ===')
for m in re.finditer(r'<link[^>]*>|<script[^>]*src="[^"]+"[^>]*>', h[:8000]):
    print(' ', m.group(0)[:160])

# 3. 根 index.html 是否存在？
print('\n根 index.html exists:', os.path.exists(os.path.join(base,'index.html')))
print('web/index.html vs 根: web 是主页面 (52KB)')
