# -*- coding: utf-8 -*-
import io, sys, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

h = open(r'C:\Users\Administrator\lingxi-engine\web\design-preview.html', encoding='utf-8').read()

# 抓全部 @keyframes 块（含嵌套花括号）
kfs = re.findall(r'@keyframes\s+([\w-]+)\s*\{', h)
print('keyframes found:', kfs)

# 找 lx-flow 和 lShine 定义
for name in ['lx-flow', 'lShine', 'lx-sat']:
    i = h.find('@keyframes ' + name)
    if i >= 0:
        print('---', name, '@', i, '---')
        print(h[i:i+260])
    else:
        print('!!! MISSING @keyframes', name)
        # 也许动画引用但没定义？检查引用
        j = h.find('animation:' + name)
        k = h.find('animation:' + name + ' ')
        print('  refs (animation:):', j, k)
        j2 = h.find('animation-duration' )
