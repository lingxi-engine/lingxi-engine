# -*- coding: utf-8 -*-
"""步骤7：mobile.css 适配新 logo + 同步根目录 css"""
import io, sys, re, os, shutil
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

base = r'C:\Users\Administrator\lingxi-engine'

# ── 1. mobile.css 适配 ──
mob = os.path.join(base, 'web', 'css', 'mobile.css')
mcss = open(mob, encoding='utf-8').read()
orig = mcss

# 375px 下旧规则 .topnav .logo span{display:none} → 隐藏英文保留主字
old_rule = '.topnav .logo span {\n    display: none;\n  }'
new_rule = '.topnav .logo-txt i {\n    display: none;\n  }\n  .topnav .logo-txt b {\n    font-size: 18px;\n  }\n  .topnav .logo-mark {\n    width: 40px;\n    height: 40px;\n  }'
if old_rule in mcss:
    mcss = mcss.replace(old_rule, new_rule)
    print('[1] mobile.css 375px rule adapted')
else:
    print('[1] !!! old rule not found, check manually')
    # 试试其他形式
    m2 = re.search(r'\.topnav \.logo span\s*\{[^}]*\}', mcss)
    if m2:
        mcss = mcss[:m2.start()] + '.topnav .logo-txt i{display:none}\n  .topnav .logo-txt b{font-size:18px}\n  .topnav .logo-mark{width:40px;height:40px}' + mcss[m2.end():]
        print('[1b] regex adapted')

# 768px 下 .topnav .logo{font-size:16px} 保持（主字在 b 上 24px 不受影响，OK）

open(mob, 'w', encoding='utf-8', newline='\n').write(mcss)
print('[2] mobile.css written, len', len(mcss), '(was', len(orig), ')')

# ── 2. 同步根目录 css/style.css（web 版为准）──
src = os.path.join(base, 'web', 'css', 'style.css')
dst = os.path.join(base, 'css', 'style.css')
shutil.copy(src, dst)
print('[3] root css/style.css synced (', os.path.getsize(dst), 'bytes )')

# 根 mobile.css 也同步
src2 = os.path.join(base, 'web', 'css', 'mobile.css')
dst2 = os.path.join(base, 'css', 'mobile.css')
shutil.copy(src2, dst2)
print('[4] root css/mobile.css synced')

# ── 3. 根目录是否有 index.html？没有。admin/market 引用检查过。根 css/style.css 是否被其他页面引用？
# 检查根目录所有 html 引用 style.css 的情况
print('\n=== 根目录引用 css/style.css 的页面 ===')
import glob
for f in glob.glob(os.path.join(base, '*.html')):
    h = open(f, encoding='utf-8', errors='replace').read()
    if 'css/style.css' in h or 'style.css' in h:
        print(' ', os.path.basename(f))
print('done')
