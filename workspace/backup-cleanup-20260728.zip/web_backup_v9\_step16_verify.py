# -*- coding: utf-8 -*-
"""步骤16：复验 index.html + 同步根 css"""
import io, sys, re, os, shutil
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

base = r'C:\Users\Administrator\lingxi-engine'

# index.html 复验
p = os.path.join(base, 'web', 'index.html')
h = open(p, encoding='utf-8').read()
print('index.html len:', len(h))
print('logo-mark count:', h.count('logo-mark'))
m = re.search(r'<a class="logo"[^>]*>.*?</a>', h, re.S)
if m:
    seg = m.group(0)
    print('logo segment len:', len(seg))
    print('has sat-front:', 'sat-front' in seg, '| has gOrb:', 'gOrb' in seg)
    # 检查是否出现重复 svg（并行会话可能又插了）
    print('logo segment svg count:', seg.count('<svg'))
    print('logo segment logo-mark count:', seg.count('logo-mark'))
# 检查文件里有没有两套 logo 标签
print('total <a class="logo" occurrences:', h.count('<a class="logo"'))

# 同步根 css
for f in ['style.css', 'mobile.css']:
    src = os.path.join(base, 'web', 'css', f)
    dst = os.path.join(base, 'css', f)
    shutil.copy(src, dst)
    print('synced root css/', f, os.path.getsize(dst), 'bytes')

# 根 css/style.css 校验
rc = open(os.path.join(base, 'css', 'style.css'), encoding='utf-8').read()
from collections import Counter
kf = re.findall(r'@keyframes\s+([\w-]+)', rc)
print('root style.css keyframes dup:', [k for k, c in Counter(kf).items() if c > 1] or 'none')
print('root braces:', rc.count('{') - rc.count('}'))
