# -*- coding: utf-8 -*-
"""步骤12：查看第二套 logo CSS 完整内容"""
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

p = r'C:\Users\Administrator\lingxi-engine\web\css\style.css'
css = open(p, encoding='utf-8').read()

print('=== 7400-10200 ===')
print(css[7400:10200])
