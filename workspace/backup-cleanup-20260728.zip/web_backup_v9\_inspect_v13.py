# -*- coding: utf-8 -*-
import io, re
s = io.open('design-preview.html', encoding='utf-8').read()
m = re.search(r'<svg class="logo-mark".*?</svg>', s, re.S)
svg = m.group(0)
classes = re.findall(r'class="([^"]+)"', svg)
out = ['=== logo-mark svg classes ===']
out.extend(classes)
out.append('--- svg length: %d ---' % len(svg))
# 检查 CSS 引用 vs SVG 实际 class
css_refs = ['halo','ripple','nucleus-glow','nucleus-dot','orbit-dot','l-halo','l-nucleus','l-core','l-shine','l-sat','l-vein']
for c in css_refs:
    out.append('CSS ref %s: %d | SVG class %s: %d' % (c, s.count('.'+c), c, svg.count('class="'+c)))
io.open('_v13_cls.txt','w',encoding='utf-8').write('\n'.join(out))
print('inspect done')
