# -*- coding: utf-8 -*-
"""步骤5：确认根目录页面引用哪个 css"""
import io, sys, re, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

base = r'C:\Users\Administrator\lingxi-engine'

for fname in ['admin.html', 'market.html', 'model-management.html', 'install.html', 'test.html']:
    p = os.path.join(base, fname)
    if not os.path.exists(p):
        continue
    h = open(p, encoding='utf-8', errors='replace').read()
    css_links = re.findall(r'<link[^>]*stylesheet[^>]*>', h)
    print(f'=== {fname} ===')
    for l in css_links:
        print('  ', l.strip()[:130])

# web 下的页面
print()
for fname in ['admin.html', 'market.html', 'model-management.html', 'install.html']:
    p = os.path.join(base, 'web', fname)
    if not os.path.exists(p):
        continue
    h = open(p, encoding='utf-8', errors='replace').read()
    css_links = re.findall(r'<link[^>]*stylesheet[^>]*>', h)
    print(f'=== web/{fname} ===')
    for l in css_links:
        print('  ', l.strip()[:130])

# mobile 目录
print()
print('=== mobile/ 目录 ===')
mp = os.path.join(base, 'mobile')
if os.path.isdir(mp):
    for root, dirs, files in os.walk(mp):
        for f in files[:20]:
            print('  ', os.path.join(root, f).replace(base, '.'))
