# -*- coding: utf-8 -*-
import io, sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
p = r'C:\Users\Administrator\lingxi-engine\web\design-preview.html'
s = io.open(p, encoding='utf-8').read()

# 1) 主题按钮文字：大粉红 -> 粉红
# 2) CSS 注释对齐
old_btn = '>大粉红</button>'
new_btn = '>粉红</button>'
old_cmt = '/* === 主题六：大粉红 Pink === */'
new_cmt = '/* === 主题六：粉红 Pink === */'

cnt_btn = s.count(old_btn)
cnt_cmt = s.count(old_cmt)
s = s.replace(old_btn, new_btn)
s = s.replace(old_cmt, new_cmt)

# 兜底：任何残留的“大粉红”一并替换
cnt_left = s.count('大粉红')

io.open(p, 'w', encoding='utf-8', newline='').write(s)
print('btn replaced:', cnt_btn, '| cmt replaced:', cnt_cmt, '| remaining 大粉红:', cnt_left)
print('has 粉红 button:', '>粉红</button>' in s)
print('wallet note ok:', '功能暂未开放，敬请期待' in s)
