# -*- coding: utf-8 -*-
"""步骤9：整体验证"""
import io, sys, re, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

base = r'C:\Users\Administrator\lingxi-engine'

# ── 1. index.html 结构验证 ──
h = open(os.path.join(base, 'web', 'index.html'), encoding='utf-8').read()
print('=== index.html ===')
print('len:', len(h))
# svg 闭合
svg_open = h.count('<svg')
svg_close = h.count('</svg>')
print('svg open/close:', svg_open, svg_close)
# logo 结构
m = re.search(r'<a class="logo"[^>]*>.*?</a>', h, re.S)
if m:
    seg = m.group(0)
    print('logo tag len:', len(seg))
    print('has logo-mark:', 'logo-mark' in seg, '| has logo-txt:', 'logo-txt' in seg, '| has data-i18n app.name:', 'data-i18n="app.name"' in seg)
# i18n 字典是否含 app.name 且值是什么
i18n_files = []
for root, dirs, files in os.walk(os.path.join(base, 'web')):
    for f in files:
        if f.endswith('.js') or f.endswith('.json'):
            p = os.path.join(root, f)
            try:
                c = open(p, encoding='utf-8', errors='replace').read()
                if 'app.name' in c or '灵犀' in c:
                    i18n_files.append(p)
            except: pass
print('i18n-related files:', i18n_files)

# ── 2. style.css 验证 ──
css = open(os.path.join(base, 'web', 'css', 'style.css'), encoding='utf-8').read()
print('\n=== style.css ===')
print('len:', len(css))
# keyframes 重复检查
kf = re.findall(r'@keyframes\s+([\w-]+)', css)
from collections import Counter
dup = [k for k, v in Counter(kf).items() if v > 1]
print('keyframes:', Counter(kf))
print('duplicates:', dup if dup else 'none')
# 花括号平衡
print('braces balance:', css.count('{') - css.count('}'))
# 旧 logo 规则残留
print('old .topnav .logo{font-weight:700 residue:', 'font-weight:700;font-size:15px' in css)
print('has lx-sat:', 'lx-sat' in css, '| has lShine:', 'lShine' in css)

# ── 3. mobile.css 验证 ──
mc = open(os.path.join(base, 'web', 'css', 'mobile.css'), encoding='utf-8').read()
print('\n=== mobile.css ===')
print('len:', len(mc))
print('has .logo span hide:', '.logo span' in mc)
print('has .logo-txt i hide:', '.logo-txt i' in mc)

# ── 4. 检查 app.js / 其他 JS 是否操作 .logo 文本 ──
print('\n=== JS 中 logo 相关操作 ===')
for root, dirs, files in os.walk(os.path.join(base, 'web')):
    for f in files:
        if f.endswith('.js'):
            p = os.path.join(root, f)
            c = open(p, encoding='utf-8', errors='replace').read()
            for m in re.finditer(r'.{60}(querySelector\([^)]*logo[^)]*\)|getElementsByClassName\([^)]*logo[^)]*\)|innerHTML[^;]*logo[^;]*).{60}', c):
                print(' ', os.path.basename(p), ':', m.group(0).replace('\n', ' ')[:180])
